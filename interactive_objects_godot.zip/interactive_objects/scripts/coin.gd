extends Area2D # Монета є зоною, яка виявляє входження фізичного тіла.
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D # Зберігаємо посилання на візуальну анімацію.
@onready var collision_shape: CollisionShape2D = $CollisionShape2D # Зберігаємо посилання на форму зіткнення.
var collected := false # Не дозволяємо зібрати монету повторно.
func _ready() -> void: # Виконуємо налаштування після створення вузла.
    body_entered.connect(_on_body_entered) # Підключаємо сигнал входження тіла.
    if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation("spin"): # Перевіряємо анімацію обертання.
        animated_sprite.play("spin") # Запускаємо постійну анімацію монети.
func _on_body_entered(body: Node2D) -> void: # Обробляємо тіло, яке увійшло в монету.
    if not body is Player or collected: # Ігноруємо не-гравця та повторний виклик.
        return # Завершуємо обробник без дій.
    collected = true # Позначаємо монету зібраною.
    collision_shape.set_deferred("disabled", true) # Вимикаємо колізію безпечно для поточного physics-кроку.
    if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation("collect"): # Перевіряємо анімацію збору.
        animated_sprite.play("collect") # Запускаємо ефект збору.
        await animated_sprite.animation_finished # Очікуємо завершення ефекту.
    queue_free() # Видаляємо монету зі сцени.
