# Интерактивные объекты Godot 4

## Структура

- `scripts/player.gd` — `class_name Player`, движение, гравитация и прыжок.
- `scripts/coin.gd` — `Area2D/AnimatedSprite2D/CollisionShape2D`, сбор монеты через `body_entered`.
- `scripts/chest.gd` — закрытое и открытое состояние сундука.
- `scripts/door.gd` — дверь с `StaticBody2D`-преградой и зоной `Area2D`.
- `scripts/acid_pool.gd` — опасная зона с `body_entered` и `body_exited`.

## Узлы сцен

```text
Coin (Area2D) [coin.gd]
├── AnimatedSprite2D (анимации spin, collect)
└── CollisionShape2D

Chest (Area2D) [chest.gd]
├── AnimatedSprite2D (idle, open; open без Loop)
└── CollisionShape2D

Door (Area2D) [door.gd]
├── AnimatedSprite2D (closed, open)
├── CollisionShape2D (зона приближения)
└── Obstacle (StaticBody2D)
    └── CollisionShape2D (коллизия стены)

AcidPool (Area2D) [acid_pool.gd]
├── AnimatedSprite2D (acid_idle, Loop)
└── CollisionShape2D (форма вдоль лужи)
```

Для каждого `Area2D` можно подключить сигнал `body_entered` через вкладку **Node → Signals**. Скрипты также подключают сигналы в `_ready()`, поэтому вручную подключать их дважды не нужно.

У `Chest/AnimatedSprite2D` создайте анимации `idle` и `open`; у `open` отключите **Loop**. Для `Door/AnimatedSprite2D` создайте `closed` и `open`. Для визуала используйте собственные текстуры или `SpriteFrames`.
